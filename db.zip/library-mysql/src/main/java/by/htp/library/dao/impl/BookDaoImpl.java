package by.htp.library.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

import by.htp.library.dao.BookDao;
import by.htp.library.entity.Book;

public class BookDaoImpl implements BookDao {
	
	private static final String SQL_SELECT_BOOK = "SELECT * FROM book WHERE id_book = ?";
	private static final String SQL_SELECT_LISTBOOK = "SELECT * FROM book";
	private static final String SQL_UPDATE_BOOK = "UPDATE book SET title = ? WHERE id_book = ?";
	private static final String SQL_DELETE_BOOK = "DELETE FROM book WHERE id_book = ?";
	private static final String SQL_INSERT_BOOK = "INSERT INTO book VALUES (?, ?, ?)";
	
	
	private Connection connect() {
	Connection connection = null;
	ResourceBundle rb = ResourceBundle.getBundle("db_config");
	
	String driver = rb.getString("db.driver");
	String login = rb.getString("db.login");
	String pass = rb.getString("db.pass");
	String url = rb.getString("db.url");
	
		
		try {	
			Class.forName(driver);
			connection = DriverManager.getConnection(url, login, pass);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return connection;
	}
	
	private void closeConnection(Connection connection) {
		if(connection!=null) {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Book read() {
		Connection connection = connect();
		Book book = null;
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		
		try {
			PreparedStatement ps = connection.prepareStatement(SQL_SELECT_BOOK);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				book = new Book();
				
				book.setId(rs.getInt("id_book"));;
				book.setTitle(rs.getString("title"));	
			}	
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		
//		Statement st = connection.createStatement();		

		return book;
	}

	public List<Book> listBooks() {
		
		Connection connection = connect();
		List<Book> listBook = new ArrayList<>();
		Book book = null;
		
		try {
			PreparedStatement ps = connection.prepareStatement(SQL_SELECT_LISTBOOK);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				book = new Book();
				book.setId(rs.getInt("id_book"));;
				book.setTitle(rs.getString("title"));	
				listBook.add(book);	
			}	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	
		return listBook;
	}

	public void update(Book book) {
		Connection connection = connect();
		
		try {
			PreparedStatement ps = connection.prepareStatement(SQL_UPDATE_BOOK);
			
			ps.setString(1, "new title");
			ps.setInt(2, book.getId());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			

	}
	
	public void delete(Book book) {
		Connection connection = connect();
		
		try {
			PreparedStatement ps = connection.prepareStatement(SQL_DELETE_BOOK);
			ps.setInt(1, book.getId());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			

	}
	
	public void insert() {
		Connection connection = connect();
		List<Book> listBook = listBooks();
		Book lastBook = listBook.get(listBook.size()-1);
		int insertId = lastBook.getId()+1;
		
		try {
			PreparedStatement ps = connection.prepareStatement(SQL_INSERT_BOOK);
			ps.setInt(1, insertId);
			ps.setString(2, "new book");
			ps.setInt(3, 1);
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			

	}
	
//	public int scanningId() {
//		Scanner scanner = new Scanner(System.in);
//		int id = scanner.nextInt();
//		scanner.close();
//		return id;
//		
//	}

}
