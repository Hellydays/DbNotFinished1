package by.htp.library.dao;

import java.util.List;

import by.htp.library.entity.Book;

public interface BookDao {

	// always public abstract in interface

	Book read();

	List<Book> listBooks();

}
